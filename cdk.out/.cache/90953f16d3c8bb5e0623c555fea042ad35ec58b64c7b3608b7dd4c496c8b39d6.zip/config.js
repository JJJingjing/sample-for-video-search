window.API_CONFIG = {
  API_ENDPOINT: 'https://gywv4hstg1.execute-api.us-west-2.amazonaws.com/prod'
};
