window.API_CONFIG = {
  API_ENDPOINT: 'https://<<marker:0xbaba:0>>.execute-api.us-west-2.amazonaws.com/prod',
  CLOUDFRONT_URL: 'https://<<marker:0xbaba:1>>',
  VIDEO_BASE_URL: 'https://<<marker:0xbaba:2>>/video-input'
};